package com.example.AccountingMangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountingMangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
